# Site-CV

A site that I made for a homework in CS class. It show a bit of what I made in past on godot. It'll also contain a test with a program made by a .haruSyren(); , a friend of mine.
